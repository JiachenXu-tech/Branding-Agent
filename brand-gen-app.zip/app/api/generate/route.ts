import { NextResponse } from 'next/server';
import { readFile } from 'fs/promises';
import path from 'path';
import { generateContent } from '@/lib/rag';

let lastUploadedProductText = '';

export async function POST() {
  try {
    const tmpPath = path.join('/tmp', 'last-product.txt');
    lastUploadedProductText = await readFile(tmpPath, 'utf-8');
    const result = await generateContent(lastUploadedProductText);
    return NextResponse.json(result);
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: '生成失败' }, { status: 500 });
  }
}
